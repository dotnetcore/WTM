import Vue from "vue";
import App from "@/pages/app.vue";
/* eslint-disable */
const app = new Vue({
    render(h) {
        return h(App, {
            props: {
                projectName: "login"
            }
        });
    }
});

app.$mount("#App");
