<template>
  <div class="app-main">
    数据：
    {{ JSON.stringify(list) }}
  </div>
</template>

<script lang="ts">
import { Component, Vue } from "vue-property-decorator";
import axios from "axios";

@Component
export default class App extends Vue {
    list = {};
    mounted() {
        // 参数格式
        const req = {
            method: "post",
            url: "/api/_actionlog/search",
            data: {
                SortInfo: "",
                Page: 1,
                Limit: 5,
                ITCode: "admin"
            },
            params: {},
            headers: { "Content-Type": "application/json" }
        };
        // 请求
        axios({ ...req })
            .then(res => {
                this.list = res.data;
            })
            .catch(res => {
                console.log("error", res);
            });
    }
}
</script>
