// WTM默认页面 Wtm buidin page
using WalkingTec.Mvvm.Core;

namespace WalkingTec.Mvvm.Mvc.Admin.ViewModels.ActionLogVMs
{
    public class ActionLogVM : BaseCRUDVM<ActionLog>
    {
    }
}
