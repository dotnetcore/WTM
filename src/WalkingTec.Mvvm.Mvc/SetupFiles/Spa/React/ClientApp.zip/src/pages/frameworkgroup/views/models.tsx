﻿import { Input, Switch, Icon, Select, Upload, message, Modal } from 'antd';
import * as React from 'react';
import UploadImg from 'components/form/uploadImg';
import Store from '../store';
export default {
    GroupCode: <Input placeholder="请输入 用户组编码" />,
GroupName: <Input placeholder="请输入 用户组名称" />,
GroupRemark: <Input placeholder="请输入 备注" />,
}