﻿import { Input, Switch, Icon, Select, Upload, message, Modal } from 'antd';
import * as React from 'react';
import UploadImg from 'components/form/uploadImg';
import Store from '../store';
export default {
    RoleCode: <Input placeholder="请输入 角色编号" />,
RoleName: <Input placeholder="请输入 角色名称" />,
RoleRemark: <Input placeholder="请输入 备注" />,

}