export { default as AppMain } from "./AppMain.vue";
export { default as Navbar } from "./Navbar/index.vue";
export { default as Settings } from "./Settings/index.vue";
export { default as Sidebar } from "./Sidebar/index.vue";
export { default as TagsView } from "./TagsView/index.vue";
export { default as VueRouter } from "./AppMain.vue";
// Vue.extend
