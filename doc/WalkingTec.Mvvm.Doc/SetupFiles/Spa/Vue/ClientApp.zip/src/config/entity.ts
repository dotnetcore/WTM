// 性别
export const sexList: Array<any> = [
  {
    Value: 0,
    Text: "男"
  },
  {
    Value: 1,
    Text: "女"
  }
];

// 是否
export const whether: Array<any> = [
  {
    Value: true,
    Text: "是"
  },
  {
    Value: false,
    Text: "否"
  }
];
