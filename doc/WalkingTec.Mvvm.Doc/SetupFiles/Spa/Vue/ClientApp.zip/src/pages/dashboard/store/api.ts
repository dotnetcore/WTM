const reqPath = "/_framework";

// github info
const getGithubInfo = {
  url: reqPath + "/GetGithubInfo",
  method: "get"
};
export default { getGithubInfo };
