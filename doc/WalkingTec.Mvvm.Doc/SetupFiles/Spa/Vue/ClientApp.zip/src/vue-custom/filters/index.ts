import formatTime from "./formatTime";

export default [{ key: "formatTime", value: formatTime }];
