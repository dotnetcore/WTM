import { actionType } from "@/config/enum";
import Chartist from "chartist";

export default [
  { key: "actionType", value: actionType },
  { key: "Chartist", value: Chartist }
];
