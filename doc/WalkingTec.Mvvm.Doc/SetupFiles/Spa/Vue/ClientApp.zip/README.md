## vue 版简介

演示简洁的写法：

> 大部分的方法通过 vue 的混淆（mixin）写在，./src/vue-custom/mixin/中的 action-mixin，form-mixin 中
> 按钮的增删改查 都是通用写法，如果有逻辑可以在 vue 页面写入 名字相同 可以覆盖混淆中的代码；

枚举提取公共部分 -
优化组件名称 -
优化 html 部分
