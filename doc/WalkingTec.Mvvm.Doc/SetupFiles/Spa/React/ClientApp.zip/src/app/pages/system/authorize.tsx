import * as React from 'react';

export interface IAppProps {
}

export default class IApp extends React.Component<IAppProps, any> {
  public render() {
    return (
      <div>
        
      </div>
    );
  }
}
