export default {
    'update.pwd.new': 'New password',
    'update.pwd.old': 'Old password',
    'update.pwd.confirm': 'Confirm pwd',
    'update.pwd.inconsistent': 'Passwords are inconsistent!',
};
