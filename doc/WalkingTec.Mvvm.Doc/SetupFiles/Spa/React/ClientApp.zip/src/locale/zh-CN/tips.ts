export default {
    'tips.status.401': '抱歉，您无权访问该页面',
    'tips.status.403': '抱歉，您无权访问该页面',
    'tips.status.404': '抱歉，您访问的页面不存在',
    'tips.status.500': '抱歉，服务器出错了',
    'tips.text.importExplain':'说明：请下载模版，然后在把信息输入到模版中',
    'tips.text.upload':'单击或拖动文件到该区域上载',
    'tips.success.operation':'操作成功',
    'tips.error.operation':'操作失败',
    'tips.error.import':'导入失败',
    'tips.error.file':'文件错误',
};
