export default {
    'pages.home': 'Home',
    'pages.outerChain': 'Outer chain',
    'pages.static': 'Static',
    'MenuKey.DataPrivilege': 'Data Privilege',
    'MenuKey.Log': 'Log',
    'MenuKey.GroupManagement': 'Group Management',
    'MenuKey.MenuMangement': 'Menu Mangement',
    'MenuKey.RoleManagement': 'Role Management',
    'MenuKey.SystemManagement': 'System',
    'MenuKey.UserManagement': 'User Management',
    'MenuKey.test.step': 'Level Three',
    'MenuKey.test.step2': 'Level Four',
};
