export default {
    'pages.home': 'Home'
};
