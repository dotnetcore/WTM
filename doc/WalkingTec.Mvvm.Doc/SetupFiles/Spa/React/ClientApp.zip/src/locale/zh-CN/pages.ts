export default {
    'pages.home': '首页',
    'pages.outerChain': '外链页面',
    'pages.static': '静态页面',
    'MenuKey.DataPrivilege': '数据权限',
    'MenuKey.Log': '日志',
    'MenuKey.GroupManagement': '用户组管理',
    'MenuKey.MenuMangement': '菜单管理',
    'MenuKey.RoleManagement': '角色管理',
    'MenuKey.SystemManagement': '系统管理',
    'MenuKey.UserManagement': '用户管理',
    'MenuKey.test.step': '三级菜单',
    'MenuKey.test.step2': '四级菜单',
};
