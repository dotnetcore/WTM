export default {
    'pages.home': '首页'
};
