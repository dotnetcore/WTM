export default {
    'update.pwd.new': '新密码',
    'update.pwd.old': '旧密码',
    'update.pwd.confirm': '确认密码',
    'update.pwd.inconsistent': '密码不一致!',
};
